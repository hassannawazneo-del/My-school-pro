require('dotenv').config();
const express = require('express');
const app = express();
const pg = require('pg');
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const multer = require('multer');
const upload = multer();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

function ok(res,data){res.json(Object.assign({ok:true}, data));}
function err(res,c,msg){res.status(c).json({ok:false,error:msg});}

// register (admin only ideally) - kept simple for seed usage
app.post('/api/register', async (req,res)=>{
  const {username,password,role} = req.body;
  if(!username||!password||!role) return err(res,400,'missing');
  const hash = await bcrypt.hash(password,10);
  try{ await pool.query('INSERT INTO users(username,password_hash,role) VALUES($1,$2,$3)',[username,hash,role]); ok(res,{}); }catch(e){ err(res,500,e.message) }
});

app.post('/api/login', async (req,res)=>{
  const {username,password} = req.body;
  if(!username||!password) return err(res,400,'missing');
  const r = await pool.query('SELECT id,password_hash,role FROM users WHERE username=$1',[username]);
  if(r.rowCount===0) return err(res,401,'no user');
  const u = r.rows[0];
  const okp = await bcrypt.compare(password,u.password_hash);
  if(!okp) return err(res,401,'bad');
  const token = jwt.sign({id:u.id,role:u.role,username:username}, process.env.JWT_SECRET || 'dev', {expiresIn:'12h'});
  ok(res,{token});
});

function auth(role){ return (req,res,next)=>{
  const h = req.headers.authorization?.split(' ')[1];
  if(!h) return err(res,401,'no token');
  try{ const p = jwt.verify(h, process.env.JWT_SECRET || 'dev'); if(role && p.role!==role && p.role!=='admin') return err(res,403,'forbidden'); req.user = p; next(); }catch(e){ err(res,401,'invalid token') }
};}

// settings
app.get('/api/settings', auth(), async (req,res)=>{
  const r = await pool.query('SELECT key,value FROM settings');
  const obj = {}; r.rows.forEach(row=>obj[row.key]=row.value);
  ok(res,{settings:obj});
});
app.post('/api/settings', auth('admin'), async (req,res)=>{
  const {key,value} = req.body;
  if(!key) return err(res,400,'missing');
  try{
    const up = await pool.query('UPDATE settings SET value=$1 WHERE key=$2',[value,key]);
    if(up.rowCount===0) await pool.query('INSERT INTO settings(key,value) VALUES($1,$2)',[key,value]);
    ok(res,{});
  }catch(e){ err(res,500,e.message); }
});

// license check (public)
app.get('/api/licenses/check/:key', async (req,res)=>{
  const r = await pool.query('SELECT key,active,activated_for,valid_from,valid_until FROM license_keys WHERE key=$1',[req.params.key]);
  if(r.rowCount===0) return err(res,404,'not found');
  ok(res,{license:r.rows[0]});
});

// admin create license
app.post('/api/licenses', auth('admin'), async (req,res)=>{
  const {key,months,activated_for,active} = req.body;
  const k = key || ('MSP-'+Math.random().toString(36).slice(2,12).toUpperCase());
  const now = new Date();
  const valid_from = now.toISOString().slice(0,10);
  const until = new Date(); until.setMonth(until.getMonth() + (months||1));
  const valid_until = until.toISOString().slice(0,10);
  try{
    await pool.query('INSERT INTO license_keys(key,active,activated_for,valid_from,valid_until) VALUES($1,$2,$3,$4,$5)',[k,!!active,activated_for||null,valid_from,valid_until]);
    ok(res,{key:k,valid_from,valid_until});
  }catch(e){ err(res,500,e.message); }
});

// simple health
app.get('/', (req,res)=>res.send('My School Pro API - Bright Future'));

// serve client static (single file)
app.get('/client', (req,res)=>{
  res.sendFile(__dirname + '/client.html');
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log('Server started on', port));
