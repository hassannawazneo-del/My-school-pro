# Deploy My School Pro on Render (quick)

1. Sign up on https://render.com and connect your GitHub account.
2. Create a new Web Service and point it to this repo (or use Manual Deploy with ZIP).
3. Create a Render Postgres database from the dashboard (Free). Note the DATABASE_URL.
4. In your Web Service Environment -> add variable `DATABASE_URL` with the value from Render Postgres.
5. Deploy. Once server is running, open `/client` path to access the app (e.g. https://your-service.onrender.com/client).
6. Run the SQL in `schema.sql` against your Render Postgres database (Render dashboard -> Databases -> Connect -> open psql and run contents of schema.sql).
7. Login with admin/bright_admin credentials and test license key `MSP-BRIGHT-TRIAL-2025` is active.
