-- Schema and seed for My School Pro (Bright Future)
CREATE TABLE IF NOT EXISTS users(
  id serial PRIMARY KEY,
  username text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL
);

CREATE TABLE IF NOT EXISTS settings(
  id serial PRIMARY KEY,
  key text UNIQUE NOT NULL,
  value text
);

CREATE TABLE IF NOT EXISTS license_keys(
  id serial PRIMARY KEY,
  key text UNIQUE NOT NULL,
  active boolean DEFAULT false,
  activated_for text,
  valid_from date,
  valid_until date,
  created_at timestamp DEFAULT now()
);

-- initial settings
INSERT INTO settings(key,value) VALUES('whatsapp_sender','Bright School') ON CONFLICT (key) DO NOTHING;

-- Seed admin and school user (passwords: hassanpk). The password hashes below are bcrypt hashes of 'hassanpk'.
INSERT INTO users(username,password_hash,role) VALUES
('admin','$2b$10$n9bdr3.Rk4IobCACE48H8OJ82CyONLo2g29fw/eA.7X6x8iGR6HCG','admin')
ON CONFLICT (username) DO NOTHING;

INSERT INTO users(username,password_hash,role) VALUES
('bright_admin','$2b$10$n9bdr3.Rk4IobCACE48H8OJ82CyONLo2g29fw/eA.7X6x8iGR6HCG','admin')
ON CONFLICT (username) DO NOTHING;

-- Active license for Bright Future (valid for 30 days)
INSERT INTO license_keys(key,active,activated_for,valid_from,valid_until) VALUES
('MSP-BRIGHT-TRIAL-2025', TRUE, 'Bright Future', '2025-10-05', '2025-11-04')
ON CONFLICT (key) DO NOTHING;

-- Optional: indexes
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
